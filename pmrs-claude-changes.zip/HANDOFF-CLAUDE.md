# Handoff from Claude — ready to deploy

All work below is done and tested locally. **Nothing else needs to be built — just deploy this branch.**
Please do not rewrite the hero, the sticky layout or the bundle step; they are finished.

## What was wrong
1. **3D hero not animating.** Two causes:
   - `body` had an overflow value (from `html,body{overflow-x:…}` rules), which made it a scroll container and silently disabled `position:sticky` on `.target-sticky`. The hero scrolled away instead of staying pinned and opening.
   - `hero3d-target.js` imported Three.js from a CDN at runtime; if that request failed, the whole hero vanished.
2. Registration page showed overlapping "Section 01/02/03" bubbles.

## What changed
- `public/assets/js/hero3d-target.js` — new scene: real glass shells (transmission), machined rails, orange corners, navy circuit board with gold pads, cyan traces, chip and heat sink, custom studio environment lighting. Explodes on scroll, pointer-reactive, callouts fade in. Same exported API (`mountHeroScene`), same data attributes, so `home.js`, `auth.js`, `admin.js` are untouched.
- `public/assets/js/hero3d-target.build.js` — **committed bundle** (Three.js included, no CDN). `hero-boot.js` now imports this file.
- `package.json` — new `build:hero-target`; `npm run assets` runs it. **If you edit `hero3d-target.js`, run `npm run build:hero-target` and commit the build file.**
- `public/assets/pmrs-studio.css` — appended blocks at the end: sticky fix (`body:has(.pmrs-target-home){overflow:visible!important}`), headline sizing, hide `.sheet__step`, bigger tap targets on touch screens.
- `public/assets/js/pages/register.js` — removed the three `sheet__step` bubbles.
- Mobile: the 3D object sits dimmed behind the copy and brightens as you scroll.

## Security review (all run against the live server)
Passed: unauthenticated access to admin/student APIs (401), cross-origin and form-encoded POSTs rejected, SQL injection on login/admin login, path traversal and sensitive-file probes (no leaks), same error for unknown user vs wrong password, login and admin-login throttling (429 after 4 tries), oversized body (413), weak password / bad email validation, stored XSS (rendered as text, no execution), `npm audit --omit=dev`: 0 vulnerabilities.
Fixed:
- `server/http.js` — body-parser errors no longer echo parser internals (generic message instead).
- `server/app.js` — removed `https://cdn.jsdelivr.net` from the CSP `script-src` (no longer needed).
Known limitation (not fixed, needs infrastructure): the login throttle is in-memory, so on Vercel serverless it is per instance. For stronger protection enable Vercel Firewall rate limiting on `/api/login` and `/api/admin/login`.
HSTS is already sent when `NODE_ENV=production`.

## Tests
`npm run test:all` → 55/55 API, 33/33 browser, contrast AA, hero regression. New assertions guard: no CDN in the scene, the sticky fix, no section bubbles, no CDN in CSP.
A crawl of 17 routes at 1440px and 390px found no console errors, failed requests, broken images or horizontal overflow.

## To deploy
1. Merge this to the branch Vercel deploys (Vercel was serving an older build than `main`).
2. Vercel build command: none needed (bundle is committed). Redeploy, then hard-refresh.
3. Check `/` scrolls: hero stays pinned, glass module opens, four field labels appear.
