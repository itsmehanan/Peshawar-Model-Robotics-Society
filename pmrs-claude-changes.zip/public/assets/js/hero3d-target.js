import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

export function mountHeroScene(canvas,{reducedMotion=false}={}){
  let renderer;
  try{renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});}catch(error){throw error;}
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));
  renderer.toneMapping=THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure=1.05;

  /* studio environment: dark room, crisp softboxes and one orange rim light */
  const envScene=new THREE.Scene();
  envScene.add(new THREE.Mesh(new THREE.BoxGeometry(40,40,40),new THREE.MeshBasicMaterial({color:0x04060a,side:THREE.BackSide})));
  function panel(w,h,x,y,z,color,intensity){
    const mesh=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshBasicMaterial({color:new THREE.Color(color).multiplyScalar(intensity),side:THREE.DoubleSide}));
    mesh.position.set(x,y,z);mesh.lookAt(0,0,0);envScene.add(mesh);
  }
  panel(18,4,0,14,5,0xbcd4ff,6);panel(3,16,-13,2,4,0xffffff,4);panel(3,16,13,0,-3,0xff5a1f,5);
  panel(14,2,0,-10,7,0x7d9cd0,2.5);panel(10,10,0,4,-14,0xffffff,1.2);panel(2,12,6,3,12,0xffffff,3);
  const pmrem=new THREE.PMREMGenerator(renderer);
  const env=pmrem.fromScene(envScene,.015).texture;
  pmrem.dispose();
  envScene.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});

  const glass=new THREE.MeshPhysicalMaterial({color:0xffffff,metalness:0,roughness:.035,transmission:1,thickness:.9,ior:1.5,envMap:env,envMapIntensity:1.6,clearcoat:1,clearcoatRoughness:.02,attenuationColor:0x8fb3e6,attenuationDistance:1.4,specularIntensity:1});
  const metal=new THREE.MeshStandardMaterial({color:0xc9ced6,metalness:1,roughness:.2,envMap:env,envMapIntensity:1.4});
  const steel=new THREE.MeshStandardMaterial({color:0x7c828c,metalness:1,roughness:.38,envMap:env,envMapIntensity:1.1});
  const pcb=new THREE.MeshStandardMaterial({color:0x0b1424,metalness:.5,roughness:.5,envMap:env,envMapIntensity:.8});
  const dark=new THREE.MeshStandardMaterial({color:0x0d0f13,metalness:.7,roughness:.35,envMap:env});
  const gold=new THREE.MeshStandardMaterial({color:0xe0b45f,metalness:1,roughness:.3,envMap:env});
  const orange=new THREE.MeshStandardMaterial({color:0xff5a1f,metalness:.25,roughness:.38,envMap:env,emissive:0x3a0f00});
  const glow=new THREE.MeshBasicMaterial({color:0x52d6ff});
  function box(w,h,d,material,x=0,y=0,z=0,r=.16){
    const mesh=new THREE.Mesh(new RoundedBoxGeometry(w,h,d,4,Math.min(w,h,d)*r),material);mesh.position.set(x,y,z);return mesh;
  }
  function cylinder(radius,height,material,x,y,z){
    const mesh=new THREE.Mesh(new THREE.CylinderGeometry(radius,radius,height,28),material);mesh.position.set(x,y,z);return mesh;
  }

  const hero=new THREE.Group(),top=new THREE.Group(),mid=new THREE.Group(),bottom=new THREE.Group();
  const S=2.3;
  /* glass shells with machined rails so the edges read as real objects */
  [[top,1],[bottom,-1]].forEach(([group,sign])=>{
    group.add(box(S,.6,S,glass,0,0,0,.24));
    [-1,1].forEach(k=>{
      group.add(box(S+.04,.05,.06,metal,0,sign*.3,k*(S/2),.4));
      group.add(box(.06,.05,S+.04,metal,k*(S/2),sign*.3,0,.4));
    });
    [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([x,z])=>group.add(box(.3,.56,.3,orange,x*(S/2-.02),0,z*(S/2-.02),.3)));
  });
  bottom.add(box(1.5,.2,.34,dark,0,-.02,S/2+.04,.2));
  [-.45,-.15,.15,.45].forEach(x=>bottom.add(box(.1,.06,.06,metal,x,-.02,S/2+.23,.3)));
  bottom.add(box(.12,.05,.05,glow,.9,.18,S/2+.02,.3));

  /* circuit board: navy substrate, gold pads, cyan traces, chip and heat sink */
  mid.add(box(2,.08,2,pcb,0,0,0,.2));
  mid.add(box(.95,.15,.95,steel,-.1,.11,-.05,.12),box(.8,.04,.8,metal,-.1,.2,-.05,.1),box(.3,.03,.3,dark,-.1,.23,-.05,.1),box(.1,.04,.1,glow,-.1,.25,-.05,.3));
  for(let i=0;i<7;i++)mid.add(box(.05,.22,.62,orange,.62+i*.1,.15,-.3,.2));
  for(let i=0;i<9;i++){mid.add(box(.1,.03,.05,gold,-.8+i*.2,.05,.9,.3));mid.add(box(.05,.03,.1,gold,-.92,.05,-.75+i*.19,.3));}
  [[-.65,.55],[-.45,.62],[.35,.58]].forEach(([x,z])=>mid.add(cylinder(.07,.17,metal,x,.12,z)));
  const trace=(w,d,x,z)=>mid.add(box(w,.012,d,glow,x,.048,z,.2));
  trace(.9,.025,-.4,.4);trace(.025,.5,-.85,.15);trace(.6,.025,.3,.3);trace(.025,.4,.6,.5);trace(.7,.025,.05,-.55);
  hero.add(top,mid,bottom);hero.rotation.x=.42;

  const scene=new THREE.Scene();scene.add(hero);
  const key=new THREE.DirectionalLight(0xffffff,1);key.position.set(3,5,4);scene.add(key);
  const rim=new THREE.DirectionalLight(0xff7a3d,.9);rim.position.set(-4,1,-3);scene.add(rim);
  const camera=new THREE.PerspectiveCamera(32,1,.1,50);camera.position.set(0,0,9.4);

  function poster(kind){
    const group=new THREE.Group(),posterScene=new THREE.Scene();
    if(kind==='robotics'){
      const ring=new THREE.Mesh(new THREE.TorusGeometry(1,.2,32,96),metal);group.add(ring);
      const ring2=new THREE.Mesh(new THREE.TorusGeometry(.8,.08,24,96),orange);ring2.rotation.y=1.2;group.add(ring2);
      group.add(new THREE.Mesh(new THREE.SphereGeometry(.62,48,48),glass));
      group.add(new THREE.Mesh(new THREE.SphereGeometry(.28,32,32),glow));
    }else if(kind==='science'){
      group.add(new THREE.Mesh(new THREE.SphereGeometry(.85,64,64),glass));
      const neck=new THREE.Mesh(new THREE.CylinderGeometry(.28,.28,.9,48,1,true),glass);neck.position.y=1;group.add(neck);
      const liquid=new THREE.Mesh(new THREE.SphereGeometry(.62,48,48),orange);liquid.position.y=-.12;group.add(liquid);
      const rim=new THREE.Mesh(new THREE.TorusGeometry(.3,.05,16,48),metal);rim.rotation.x=Math.PI/2;rim.position.y=1.45;group.add(rim);
    }else if(kind==='engineering'){
      const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.9,.9,.4,48),metal);wheel.rotation.x=Math.PI/2;group.add(wheel);
      for(let i=0;i<12;i++){const a=i/12*Math.PI*2,tooth=box(.3,.34,.4,metal,Math.cos(a)*1.05,Math.sin(a)*1.05,0);tooth.rotation.z=a;group.add(tooth);}
      const hub=new THREE.Mesh(new THREE.CylinderGeometry(.42,.42,.46,40),orange);hub.rotation.x=Math.PI/2;group.add(hub);
      const bore=new THREE.Mesh(new THREE.CylinderGeometry(.2,.2,.5,32),dark);bore.rotation.x=Math.PI/2;group.add(bore);
    }else{
      group.add(box(1.7,.55,1.7,glass));
      group.add(box(1,.16,1,metal,0,-.02,0));
      group.add(box(.5,.18,.5,dark,0,.04,0));
      group.add(box(.1,.04,.1,glow,.1,.15,.1));
      for(let i=0;i<7;i++){const p=-.7+i*.233;group.add(box(.09,.05,.34,orange,p,-.05,1));group.add(box(.09,.05,.34,orange,p,-.05,-1));group.add(box(.34,.05,.09,orange,1,-.05,p));group.add(box(.34,.05,.09,orange,-1,-.05,p));}
    }
    group.rotation.set(.5,-.6,.05);posterScene.add(group);
    const light=new THREE.DirectionalLight(0xffffff,1.1);light.position.set(3,4,5);posterScene.add(light);
    return posterScene;
  }
  function bakePosters(){
    const posterCamera=new THREE.PerspectiveCamera(30,1,.1,50);posterCamera.position.set(0,0,7.2);
    const oldRatio=renderer.getPixelRatio(),oldSize=new THREE.Vector2();renderer.getSize(oldSize);
    renderer.setPixelRatio(1);renderer.setSize(560,560,false);renderer.setClearColor(0x000000,0);
    document.querySelectorAll('.pmrs-target-home img[data-k]').forEach(img=>{
      renderer.render(poster(img.dataset.k),posterCamera);
      try{img.src=canvas.toDataURL('image/png');}catch{}
    });
    renderer.setPixelRatio(oldRatio);renderer.setSize(oldSize.x,oldSize.y,false);renderer.setClearColor(0x000000,0);
  }

  const isAuthScene=!canvas.closest('[data-hero-stage]');
  let baseScale=1,baseX=0,baseY=0,hover=0,targetHover=0,wideMode=true;
  let vw=0,vh=0;
  function size(){
    const stage=canvas.parentElement,w=stage.clientWidth,h=stage.clientHeight;
    if(w===vw&&h===vh)return;
    vw=w;vh=h;renderer.setSize(w,h,false);camera.aspect=w/h;
    const wide=w/h>1.15&&w>860;
    wideMode=wide;
    if(isAuthScene){
      camera.fov=27;
      baseX=0;baseY=0;baseScale=1.28;
    }else{
      camera.fov=wide?32:38;
      baseX=wide?2.05:0;
      baseY=wide?-.2:-1.1;
      baseScale=wide?.88:.74;
    }
    camera.updateProjectionMatrix();
    hero.position.set(baseX,baseY,0);
    hero.scale.setScalar(baseScale);
  }
  const smooth=(a,b,x)=>{x=Math.min(1,Math.max(0,(x-a)/(b-a)));return x*x*(3-2*x);};
  const stage=canvas.closest('[data-hero-stage]')||canvas.parentElement;
  const textBlock=stage.querySelector('[data-hero-copy]');
  const calls=[...stage.querySelectorAll('[data-hero-call]')];
  let mx=0,my=0,tx=0,ty=0,visible=true,disposed=false,frame=0;
  const onPointer=e=>{
    const rect=canvas.getBoundingClientRect();
    if(!rect.width||!rect.height)return;
    tx=Math.max(-1,Math.min(1,((e.clientX-rect.left)/rect.width-.5)*2));
    ty=Math.max(-1,Math.min(1,((e.clientY-rect.top)/rect.height-.5)*2));
    targetHover=1;
  };
  const onLeave=()=>{tx=0;ty=0;targetHover=0;};
  stage.addEventListener('pointermove',onPointer,{passive:true});
  stage.addEventListener('pointerleave',onLeave,{passive:true});
  const observer=new IntersectionObserver(([entry])=>{visible=entry.isIntersecting;if(visible)start();else stop();},{threshold:0});
  observer.observe(stage);
  const t0=performance.now();
  function render(now){
    if(disposed||!visible)return;
    size();
    const travel=Math.max(1,stage.offsetHeight-innerHeight);
    const p=Math.min(1,Math.max(0,-stage.getBoundingClientRect().top/travel));
    const explode=smooth(.08,.62,p);
    mx+=(tx-mx)*.075;my+=(ty-my)*.075;hover+=(targetHover-hover)*.09;
    const spin=reducedMotion?0:(now-t0)*.00012;
    top.position.y=.62+explode*.92;
    bottom.position.y=-.62-explode*.7;
    mid.position.y=explode*.2;
    hero.rotation.y=-.5+spin+p*2.2+mx*(isAuthScene ? 0.9 : 0.82);
    hero.rotation.x=.42+my*.48-explode*.12;
    hero.position.x=baseX+mx*.13-(wideMode&&!isAuthScene?explode*1.05:0);
    hero.position.y=baseY-my*.10;
    hero.scale.setScalar(baseScale*(1+hover*.045)*(1-explode*.08));
    if(textBlock){const opacity=1-smooth(.04,.3,p);textBlock.style.opacity=opacity;textBlock.style.transform='translateY('+(-smooth(.04,.3,p)*30)+'px)';textBlock.style.pointerEvents=p>.3?'none':'auto';}
    calls.forEach((call,i)=>{
      const opacity=smooth(.27+i*.055,.47+i*.055,p);
      call.style.opacity=opacity;
      call.style.transform='translateX('+((1-opacity)*34)+'px) translateY('+((1-opacity)*8)+'px)';
    });
    if(!isAuthScene)canvas.style.opacity=wideMode?1:.32+.68*smooth(.04,.3,p);
    renderer.render(scene,camera);
    frame=requestAnimationFrame(render);
  }
  const start=()=>{if(disposed||!visible)return;cancelAnimationFrame(frame);frame=requestAnimationFrame(render);};
  const stop=()=>{cancelAnimationFrame(frame);frame=0;};
  const resizeObserver=new ResizeObserver(size);if(canvas.parentElement)resizeObserver.observe(canvas.parentElement);
  const onVisibility=()=>{if(document.visibilityState==='visible')start();else stop();};
  document.addEventListener('visibilitychange',onVisibility);
  const onLost=e=>{e.preventDefault();stop();canvas.dispatchEvent(new CustomEvent('herocontextlost',{bubbles:true}));};
  canvas.addEventListener('webglcontextlost',onLost);
  size();bakePosters();vw=0;size();start();
  return {
    firstFrame(){renderer.render(scene,camera);return !renderer.getContext().isContextLost();},
    start,stop,
    dispose(){disposed=true;stop();observer.disconnect();resizeObserver.disconnect();stage.removeEventListener('pointermove',onPointer);stage.removeEventListener('pointerleave',onLeave);document.removeEventListener('visibilitychange',onVisibility);canvas.removeEventListener('webglcontextlost',onLost);scene.traverse(o=>{o.geometry?.dispose();if(o.material){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.dispose());}});env.dispose();renderer.dispose();}
  };
}
